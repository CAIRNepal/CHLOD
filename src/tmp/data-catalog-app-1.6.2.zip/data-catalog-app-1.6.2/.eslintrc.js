module.exports = {
  "extends": [
    "plugin:cypress/recommended"
  ],
};